chatopt data
----------------------------------------------------------------
[{"avatar":"facebook-0","agent":"facebook","link":"fb.com"}]
----------------------------------------------------------------

form sumit rquirements

{"inquireemail":"fazil hussasin","vistorname":"optional","visitoremail":"optional","visitorquestion":"optional"}
-------------------------------
widget paearance rqu
{"widgtpossition":"left","btntext":"Help","themecolor":"#a80b0b"}

-------------------------------
faqs
{"questions":["what is order",null],"answers":["order data","Once you have placed your order, we will send you a confirmation email to track the status of your order.Once your order is shipped we will send you another email along with the link to track your order.Or, you can track the status of your order from your \"order history\" section on your account page on the website."]}
