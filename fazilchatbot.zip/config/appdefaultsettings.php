<?php
return [
    //---------------Widget Possition -----------//
    "widgtpossition" => "right",
    "btntext"        => "Help",
    "themecolor"     => "#a80b0b",
    //---------------Social Media Option -----------//

    'faqs' => '{"questions":["what is order","whas is shopify"],"answers":["order data","shopify data"]}',
    'chatopt' => '[{"avatar":"facebook-0","agent":"facebook","link":"facebook.com"}]'

];
